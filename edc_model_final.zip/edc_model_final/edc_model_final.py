import json
import os
from tqdm import tqdm
import spacy
from spacy.tokens import DocBin

# Load the JSON data
with open('./edc_model_final/annotations.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

annotations = data['annotations']

# Load the spaCy model
nlp = spacy.load("en_ner_bionlp13cg_md")

# Create the DocBin object
db = DocBin()

# Filter out None elements from the annotations list
filtered_annotations = [item for item in annotations if item is not None]

# Process the filtered annotations
for text, annot in tqdm(filtered_annotations):
    doc = nlp.make_doc(text)
    ents = []
    for start, end, label in annot['entities']:
        span = doc.char_span(start, end, label=label, alignment_mode='contract')
        if span is None:
            print("Skipping entity")
        else:
            ents.append(span)
    doc.ents = ents  # Label text with the ents
    db.add(doc)

# Change directory and save the DocBin object
os.chdir("./edc_model_final")
db.to_disk("./train.spacy")


